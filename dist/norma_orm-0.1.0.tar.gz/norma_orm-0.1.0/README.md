# Norma ORM

A modern Prisma-like ORM framework for Python with dataclass support, providing type-safe database operations across PostgreSQL, SQLite, and MongoDB.

## Features

- 🎯 **Type-Safe**: Built with modern Python type hints
- 🏗️ **Dataclass-Based**: Define models using Python dataclasses
- 🔄 **Multi-Database**: Support for PostgreSQL, SQLite, and MongoDB
- 🚀 **Auto-Generation**: Automatic Pydantic schema generation
- ⚡ **Async/Sync**: Flexible synchronous and asynchronous operations
- 🛠️ **CLI Tools**: Powerful command-line interface for code generation

## Quick Start

### Installation

```bash
pip install norma-orm

# For PostgreSQL support
pip install norma-orm[postgres]

# For development
pip install norma-orm[dev]
```

### Define Models

```python
from dataclasses import dataclass
from typing import Optional
from norma import BaseModel, Field

@dataclass
class User(BaseModel):
    name: str = Field(index=True)
    email: str = Field(unique=True)
    age: int = Field(default=0)
    id: Optional[str] = Field(default=None, primary_key=True)
```

### Basic Usage

```python
from norma import NormaClient

# Initialize client
client = NormaClient(
    adapter_type="sql",  # or "mongo"
    database_url="postgresql://user:pass@localhost/db"
)

# CRUD operations
user = User(name="John", email="john@example.com", age=25)
created_user = await client.user.insert(user)
found_user = await client.user.find_by_id(created_user.id)
users = await client.user.find_many({"age": {"$gte": 18}})
```

### CLI Usage

```bash
# Initialize a new project
norma init my-project

# Generate ORM and schemas
norma generate --models ./models --output ./generated
```

## Documentation

For full documentation, visit: [https://norma-orm.readthedocs.io](https://norma-orm.readthedocs.io)

## Contributing

We welcome contributions! Please see our [Contributing Guide](CONTRIBUTING.md) for details.

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details. 